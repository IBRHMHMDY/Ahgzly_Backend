<div
    <?php echo e($attributes->gridColumn($this->getColumnSpan(), $this->getColumnStart())->class(['fi-wi-widget'])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH G:\developer\AhgzlyOnline_2026\Ahgzly_Backend\vendor\filament\widgets\resources\views/components/widget.blade.php ENDPATH**/ ?>