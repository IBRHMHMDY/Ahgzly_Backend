<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH G:\developer\AhgzlyOnline_2026\Ahgzly_Backend\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>